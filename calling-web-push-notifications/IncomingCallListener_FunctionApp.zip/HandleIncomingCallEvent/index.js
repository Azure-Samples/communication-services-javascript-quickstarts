const { getOneSignalRegistrationToken } = require('../Shared/OneSignalRegistrationTokens.js');

module.exports = async function (context, eventGridEvent) {
    try {
        const calleesOneSignalRegistrationToken = getOneSignalRegistrationToken(eventGridEvent.data.to.rawId);
        context.log('Attempting to signal user ', eventGridEvent.data.to.rawId, 'with registration token', calleesOneSignalRegistrationToken);
        const response = await fetch('https://onesignal.com/api/v1/notifications', {
            method: 'POST',
            headers: {
                'Authorization': 'Basic <Your OneSignal REST API Key>',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "app_id": "<You OneSignal app Id>",
                "contents": {
                    "en": "Incoming call"
                },
                "data": {
                    "incomingCallContext": (JSON.parse(Buffer.from(eventGridEvent.data.incomingCallContext.split('.')[1], 'base64').toString())).cc
                },
                "include_external_user_ids": [calleesOneSignalRegistrationToken],
                "url": "<Your websites URL origin>"
            })
        });
        context.log(await response.json());
    } catch(e) {
        context.error(e);
        throw e;
    }
};